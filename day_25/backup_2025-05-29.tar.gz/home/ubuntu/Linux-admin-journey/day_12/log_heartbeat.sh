#!/bin/bash

LOG_DIR="/home/ubuntu/logs"
mkdir -p $LOG_DIR

echo "$(date) System is alive" >> /home/ubuntu/logs/heartbeat.log



